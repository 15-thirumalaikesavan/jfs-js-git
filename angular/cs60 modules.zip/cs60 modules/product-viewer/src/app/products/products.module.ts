import { NgModule } from '@angular/core';
import { ProductsComponent } from './products.component';
import { ProductComponent } from './product/product.component';
import { ToUpperCasePipe } from '../shared/pipes/to-upper-case.pipe';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { ProductGuard } from '../guard/product.guard';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'products', component: ProductsComponent },
      {
        path: 'product/:productId',
        canActivate: [ProductGuard],
        component: ProductComponent
      }
    ]),
    SharedModule
  ],
  declarations: [ProductsComponent, ProductComponent, ToUpperCasePipe]
})
export class ProductsModule {}
